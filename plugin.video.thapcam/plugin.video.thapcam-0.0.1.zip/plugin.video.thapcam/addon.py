from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP1A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/605.1.15 EdgA/129.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def respphut90():
    tr = 'https://vebo.tv'
    resp90 = getlink(tr, tr,-1)
    if (resp90 is not None):
        html_content = re.sub(r"(\n\s*//.*)", "", resp90.text)
        ref = re.search(r'base_embed_url.*?("|\')([^"\s]+)("|\')', html_content)[2]
    else:
        ref = tr
    return ref
def get_tc():
    url = 'https://api.thapcam.xyz/api/match/featured/mt'
    resp = getlink(url, url,-1)
    return resp.json()['data']
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        with ThreadPoolExecutor(2) as ex:
            f1 = ex.submit(respphut90)
            f2 = ex.submit(get_tc)
            r1 = f1.result()
            r2 = f2.result()
        ref = domain(r1)
        for k in r2:
            time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d/%m')
            tg = f'[COLOR red]{time}[/COLOR]' if 'live' in k['match_status'] else time
            tenm = f'[COLOR yellow]{k["name"]}[/COLOR]' if k['commentators'] else k['name']
            tenv = f'{tg} {tenm}'
            addDir(tenm, 'list_thapcam', idk = str(k['id']), name=tenv, ref=ref, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_thapcam':
        u = f'http://api.thapcam.xyz/api/match/{params["idk"]}/meta'
        resp = getlink(u, u, -1)
        kq = resp.json()['data']
        kp = kq['play_urls']
        cm = kq['commentators']
        blv = ' - '.join((h['name'] for h in cm or []))
        for k in kp:
            tenm = f'{k["name"]} - {params["name"]} ({blv})' if cm else f'{k["name"]} - {params["name"]}'
            addDir(tenm, 'play', id = k['url'], ref=params['ref'], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        hdr = f"Referer={params['ref']}/&Origin={params['ref']}&Keep-Alive=true&User-Agent={unquote(UA)}"
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ!')
if __name__ == '__main__':
    try:
        router(sys.argv[2][1:])
    except:
        xbmcgui.Dialog().notification(addon_name, 'Không lấy được dữ liệu', ICON)