from urllib.parse import urlencode, parse_qsl, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from bs4 import BeautifulSoup
from xbmc import executebuiltin
from xbmcvfs import translatePath
from requests import Session
from json import loads, dumps
from concurrent.futures import ThreadPoolExecutor
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP1A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/605.1.15 EdgA/129.0.0.0'
ufn = 'https://thuvienhd.xyz'
userfs = 'FshareiOSApp-saCP7ssw2u7w'
keyfs = 'MkywVt2UBRHcJXUUcfsZ7XXzBSJV3dwE'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'),'plugin.video.thuvienhd')
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def get_tkfs1(search_query):
    r = getlink(f'http://phongblack.online/search-tungbui.php?author=phongblack&search={search_query}', 'http://www.google.com', 1000)
    return ((m['label'], re.search(r"url=(\S+)", m['path'])[1], m['info']['plot']) for m in (k for k in r.json()['items'] if k.get('is_playable', False) is False) if 'fshare' in m['path'])
def get_tkfs2(search_query):
    r = urlquick.post(f'https://api.timfshare.com/v1/string-query-search?query={search_query}', timeout=30, max_age=1000, headers={'user-agent': UA, 'referer': 'https://timfshare.com/', 'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'})
    return ((k['name'], k['url']) for k in r.json().get('data', []))
def get_tkfs3(search_query):
    return ((t['title'].replace('&&','-'), t['image'], t['id']) for t in getlink(f'{ufn}/?feed=fsharejson&search={search_query}', ufn, 1000).json() if getlink(f'{ufn}/?feed=fsharejson&search={search_query}', ufn, 1000).content != getlink(f'{ufn}/?feed=fsharejson&search=', ufn, 1000).content)
def get_tkfs4():
    return ((t['title'].replace('&&','-'), t['image'], t['id']) for t in loads(re.sub(r'<(.*?)\n','',getlink(f'{ufn}/?feed=fsharejson&search={search_query}', ufn, 1000).text)) if getlink(f'{ufn}/?feed=fsharejson&search={search_query}', ufn, 1000).content != getlink(f'{ufn}/?feed=fsharejson&search=', ufn, 1000).content)
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
    return os.path.exists(get_file_path(filename))
def remove_file(filename):
    if has_file_path(filename):
        os.remove(get_file_path(filename))
def userpassfs():
    username = Addon().getSetting('username')
    password = Addon().getSetting('password')
    if username and password:
        payload = {'user_email':username,'password':password,'app_key':keyfs}
        head = {'user-agent':userfs, 'content-type': 'application/json; charset=utf-8'}
        try:
            response = urlquick.post('https://api.fshare.vn/api/user/login',data=dumps(payload),headers=head,timeout=30,max_age=7200)
            headerfsvn = {'user-agent':userfs, 'cookie' : f"session_id={response.json()['session_id']}"}
            with Session() as s:
                r = s.get('https://api.fshare.vn/api/user/get', timeout=30, headers=headerfsvn)
            if r.status_code == 200:
                return (response.json()['token'], response.json()['session_id'])
            else:
                urlquick.cache_cleanup(-1)
                remove_file('.urlquick.slite3')
                userpassfs()
        except:
            urlquick.cache_cleanup(-1)
            remove_file('.urlquick.slite3')
            executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Đăng nhập thất bại', 5000, ICON))
            sys.exit()
    else:
        executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Vui lòng nhập tài khoản Fshare trong cài đặt của VN Media', 5000, ICON))
        sys.exit()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('Tìm phim', searchimg, 'Tìm phim', 'search', is_folder=True)
        T = {'Phim lẻ': 'tvhd_phimle',
            'Phim bộ': 'tvhd_phimbo',
            'Nhạc': 'tvhd_nhac'}
        dulieu = {
            'Phim mới':f'{ufn}/recent',
            'Thịnh hành':f'{ufn}/trending',
            'Thuyết minh':f'{ufn}/genre/thuyet-minh-tieng-viet',
            'Lồng tiếng':f'{ufn}/genre/long-tieng-tieng-viet',
            'H265':f'{ufn}/genre/h265',
            '3D':f'{ufn}/genre/3d',
            '4K':f'{ufn}/genre/4k',
            'ATV':f'{ufn}/genre/atv',
            'Bluray':f'{ufn}/genre/bluray-nguyen-goc',
            'TVB':f'{ufn}/genre/tvb',
            'Bộ sưu tập':f'{ufn}/genre/collection',
            'TV Shows':f'{ufn}/genre/tv-show',
            'TV':f'{ufn}/genre/tv',
            'Phim truyền hình':f'{ufn}/genre/tv-movie',
            'Phim 18':f'{ufn}/genre/18'
            }
        for b in T:
            addDir(b, ICON, b, T[b], is_folder=True)
        for h in dulieu:
            addDir(h, ICON, h, 'thuvienhd_page', url = f'{dulieu[h]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_phimle':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/phim-le',
            '3D': f'{ufn}/genre/3d',
            '4K': f'{ufn}/genre/4k',
            'Âm Nhạc': f'{ufn}/genre/am-nhac',
            'Ấn Độ': f'{ufn}/genre/india',
            'Bản quyền': f'{ufn}/genre/copyright',
            'Bí Ẩn': f'{ufn}/genre/bi-an',
            'Cao Bồi': f'{ufn}/genre/western',
            'Chiến Tranh': f'{ufn}/genre/war',
            'Chính Kịch': f'{ufn}/genre/chinh-kich',
            'Cổ Trang': f'{ufn}/genre/co-trang-phim',
            'Gây cấn': f'{ufn}/genre/gay-can',
            'Gia Đình': f'{ufn}/genre/gia-dinh',
            'Hài': f'{ufn}/genre/comedy',
            'Hàn Quốc': f'{ufn}/genre/korean',
            'Hành Động': f'{ufn}/genre/action',
            'Hình Sự': f'{ufn}/genre/crime',
            'Hồi hộp': f'{ufn}/genre/hoi-hop',
            'Hongkong': f'{ufn}/genre/hongkong',
            'Huyền Bí': f'{ufn}/genre/mystery',
            'Kinh Dị': f'{ufn}/genre/horror',
            'Lãng Mạn': f'{ufn}/genre/romance',
            'Lịch Sử': f'{ufn}/genre/history',
            'Nhạc Kịch': f'{ufn}/genre/nhac-kich',
            'Phiêu Lưu': f'{ufn}/genre/adventure',
            'Rùng Rợn': f'{ufn}/genre/thriller',
            'Tâm Lý': f'{ufn}/genre/drama',
            'Thần Thoại': f'{ufn}/genre/fantasy',
            'Thể Thao': f'{ufn}/genre/the-thao',
            'Thiếu Nhi': f'{ufn}/genre/family',
            'Tiểu Sử': f'{ufn}/genre/tieu-su',
            'Tình Cảm': f'{ufn}/genre/tinh-cam',
            'Tội Phạm': f'{ufn}/genre/toi-pham',
            'Trinh Thám': f'{ufn}/genre/trinh-tham',
            'Trung Quốc': f'{ufn}/genre/trung-quoc-series',
            'Viễn Tưởng': f'{ufn}/genre/sci-fi',
            'Việt Nam': f'{ufn}/genre/vietnamese',
            'Võ Thuật': f'{ufn}/genre/vo-thuat-phim-2',
            'Giáng Sinh': f'{ufn}/genre/giang-sinh',
            'Phim Hoạt Hình': f'{ufn}/genre/animation',
            'Phim Tài Liệu': f'{ufn}/genre/documentary',
            'Phim': f'{ufn}/genre/phim'
        }
        for k in dulieu:
            addDir(k, ICON, k, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_phimbo':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/series',
            'Phim Bộ Nigeria': f'{ufn}/genre/phi-bo-nigeria',
            'Phim Bộ Ả Rập': f'{ufn}/genre/phim-bo-a-rap',
            'Phim Bộ Ai Cập': f'{ufn}/genre/phim-bo-ai-cap',
            'Phim Bộ Ái Nhĩ Lan (Ireland)': f'{ufn}/genre/phim-bo-ai-nhi-lan-ireland',
            'Phim Bộ Ấn Độ': f'{ufn}/genre/phim-bo-an-do',
            'Phim bộ Anh': f'{ufn}/genre/phim-bo-anh',
            'Phim Bộ Áo': f'{ufn}/genre/phim-bo-ao',
            'Phim Bộ Argentina': f'{ufn}/genre/phim-bo-argentina',
            'Phim Bộ Australia': f'{ufn}/genre/phim-bo-australia',
            'Phim Bộ Ba Lan': f'{ufn}/genre/phim-bo-ba-lan',
            'Phim Bộ Bỉ': f'{ufn}/genre/phim-bo-bi',
            'Phim Bộ Bồ Đào Nha': f'{ufn}/genre/phim-bo-bo-dao-nha',
            'Phim Bộ Brazil': f'{ufn}/genre/phim-bo-brazil',
            'Phim Bộ Canada': f'{ufn}/genre/phim-bo-canada',
            'Phim Bộ Chile': f'{ufn}/genre/phim-bo-chile',
            'Phim Bộ Colombia': f'{ufn}/genre/phim-bo-colombia',
            'Phim Bộ Đài Loan': f'{ufn}/genre/phim-bo-dai-loan',
            'Phim Bộ Đan Mạch': f'{ufn}/genre/phim-bo-dan-mach',
            'Phim Bộ Đức': f'{ufn}/genre/phim-bo-duc',
            'Phim Bộ Hà Lan': f'{ufn}/genre/phim-bo-ha-lan',
            'Phim Bộ Hàn': f'{ufn}/genre/korean-series',
            'Phim Bộ Hongkong': f'{ufn}/genre/hongkong-series',
            'Phim Bộ Iceland': f'{ufn}/genre/phim-bo-iceland',
            'Phim Bộ Ireland': f'{ufn}/genre/phim-bo-ireland',
            'Phim Bộ Israel': f'{ufn}/genre/phim-bo-israel',
            'Phim Bộ Jordan': f'{ufn}/genre/phim-bo-jordan',
            'Phim Bộ Mexico': f'{ufn}/genre/phim-bo-mexico',
            'Phim Bộ Mỹ': f'{ufn}/genre/us-tv-series',
            'Phim Bộ Na Uy': f'{ufn}/genre/phim-bo-na-uy',
            'Phim Bộ Nam Phi': f'{ufn}/genre/phim-bo-nam-phi',
            'Phim Bộ New Zealand': f'{ufn}/genre/phim-bo-new-zealand',
            'Phim Bộ Nga': f'{ufn}/genre/phim-bo-nga',
            'Phim Bộ Nhật Bản': f'{ufn}/genre/phim-bo-nhat-ban',
            'Phim Bộ Phần Lan': f'{ufn}/genre/phim-bo-phan-lan',
            'Phim Bộ Pháp': f'{ufn}/genre/phim-bo-phap',
            'Phim Bộ Philippines': f'{ufn}/genre/phim-bo-philippines',
            'Phim Bộ Romania': f'{ufn}/genre/phim-bo-romania',
            'Phim Bộ Singapo': f'{ufn}/genre/phim-bo-singapo',
            'Phim Bộ Tây Ban Nha': f'{ufn}/genre/phim-bo-tay-ban-nha',
            'Phim Bộ Thái Lan': f'{ufn}/genre/phim-bo-thai-lan',
            'Phim Bộ Thổ Nhĩ Kỳ': f'{ufn}/genre/phim-bo-tho-nhi-ky',
            'Phim Bộ Thụy Điển': f'{ufn}/genre/phim-bo-thuy-dien',
            'Phim Bộ Trung Quốc': f'{ufn}/genre/phim-bo-trung-quoc',
            'Phim Bộ Việt Nam': f'{ufn}/genre/phim-bo-viet-nam',
            'Phim Bộ Ý': f'{ufn}/genre/phim-bo-y'
        }
        for k in dulieu:
            addDir(k, ICON, k, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_nhac':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/music',
            'Chương Trình Xuân': f'{ufn}/genre/chuong_trinh-xuan',
            'Lossless': f'{ufn}/genre/lossless',
            'MV Châu Á': f'{ufn}/genre/wp-chau-a',
            'MV Quốc Tế': f'{ufn}/genre/wp-quoc-te',
            'MV Việt Nam': f'{ufn}/genre/wp-viet-nam'
        }
        for k in dulieu:
            addDir(k, ICON, k, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_query = quote_plus(query)
            with ThreadPoolExecutor(4) as ex:
                f1 = ex.submit(get_tkfs1, search_query)
                f2 = ex.submit(get_tkfs2, search_query)
                f3 = ex.submit(get_tkfs3, search_query)
                f4 = ex.submit(get_tkfs4, search_query)
            try:
                for t in f3.result():
                    addDir(t[0], t[1], t[0], 'thuvienhd_link', idk = t[2], is_folder=True)
            except:
                for t in f4.result():
                    addDir(t[0], t[1], t[0], 'thuvienhd_link', idk = t[2], is_folder=True)
            try:
                for m in f1.result():
                    if '/file/' in m[1]:
                        addDir(m[0], ICON, m[2], 'play_fs', link = m[1], is_folder=False)
                    else:
                        addDir(m[0], ICON, m[2], 'index_fs', link = m[1], p=0, is_folder=True)
            except:
                pass
            try:
                for k in f2.result():
                    if 'folder' in k[1]:
                        addDir(k[0], ICON, k[0], 'index_fs', link = k[1], p=0, is_folder=True)
                    else:
                        addDir(k[0], ICON, k[0], 'play_fs', link = k[1], is_folder=False)
            except:
                pass
            endOfDirectory(HANDLE)
        else:
            quit()
    elif params['mode'] == 'thuvienhd_page':
        next_page = int(params["p"])
        trangtiep = f'{params["url"]}{next_page}'
        resp = getlink(trangtiep, trangtiep, 1000)
        soup = BeautifulSoup(resp.text, 'html.parser')
        for k in soup.select('div.items article'):
            name = k.select_one('div.data a').get_text(strip=True)
            img = k.select_one('div.poster img')['src']
            idp = k['id'].split('-')[1]
            addDir(name, img, name, 'thuvienhd_link', idk = idp, is_folder=True)
        s2 = soup.select('div.pagination a')
        for checkpage in s2:
            if str(next_page + 1) in checkpage.get_text(strip=True):
                trang = str(next_page + 1)
                addDir(f'Trang {trang}', ICON, f'Trang {trang}', 'thuvienhd_page', url = params["url"], p=trang, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'thuvienhd_link':
        url = params['idk']
        t = f'{ufn}/?feed=fsharejson&id={params["idk"]}'
        resp = getlink(t, t, 1000)
        d = resp.json()
        anh = d['image']
        mota = d['description']
        for k in d['link']:
            name = k['title']
            link = k['link']
            if 'folder' in link:
                addDir(name, anh, mota, 'index_fs', link = link, p=0, is_folder=True)
            else:
                addDir(name, anh, mota, 'play_fs', link = link, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'index_fs':
        token, session_id = userpassfs()[:2]
        folderfs = params['link']
        next_page = params['p']
        payload = {'token': token, 'url': folderfs, 'dirOnly': 0, 'pageIndex': next_page, 'limit':100}
        headerfsvn = {'user-agent':userfs, 'cookie' :  f'session_id={session_id}', 'content-type': 'application/json; charset=utf-8'}
        with Session() as s:
            kq = s.post('https://api.fshare.vn/api/fileops/getFolderList', timeout=20, data=dumps(payload), headers=headerfsvn)
            if 'furl' in kq.text:
                kj = kq.json()
                for k in kj:
                    tenm = k['name']
                    linkfs = k['furl']
                    if 'file' in k['furl']:
                        addDir(tenm, ICON, tenm, 'play_fs', link = linkfs, is_folder=False)
                    else:
                        addDir(tenm, ICON, tenm, 'index_fs', link = linkfs, p=0, is_folder=True)
                if len(kq.json())==100:
                    addDir(f'Trang {next_page + 2}', nextimg, f'Trang {next_page + 2}', 'index_fs', link = folderfs, p=next_page + 1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_fs':
        j = userpassfs()
        payload = {'zipflag':0, 'url': params['link'], 'password':'', 'token': j[0]}
        headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={j[1]}', 'content-type': 'application/json; charset=utf-8'}
        with Session() as s:
            try:
                uf = s.post('https://api.fshare.vn/api/session/download', timeout=30,data=dumps(payload),headers=headerfsvn)
            except:
                uf = s.post('https://api.fshare.vn/api/session/download', timeout=30,data=dumps(payload),headers=headerfsvn, verify=False)
        if 'location' in uf.text:
            play_item = xbmcgui.ListItem(offscreen=True)
            linkplay = re.sub(r'\s+', '%20', uf.json()['location'].strip(), flags=re.UNICODE)
            play_item.setPath(linkplay)
            setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ!')
if __name__ == '__main__':
    try:
        router(sys.argv[2][1:])
    except:
        xbmcgui.Dialog().notification(addon_name, 'Không lấy được dữ liệu', ICON)