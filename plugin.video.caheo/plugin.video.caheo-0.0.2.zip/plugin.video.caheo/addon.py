from urllib.parse import urlencode, parse_qsl, unquote
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import re, sys, urlquick, xbmcgui

addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
homeweb = 'https://watch.rkplayer.xyz'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP1A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/605.1.15 EdgA/129.0.0.0'

def addDir(title, mode, is_folder=True, **kwargs):
    if isinstance(mode, str):
        dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    else:
        dir_url = mode
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)

def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA, 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        u = 'https://api.rkdata.xyz/v1/caheo/home.html'
        r = getlink(u, u, 400)
        kq = r.json()['data']['lives']
        dq = ((k['id'], k['timeShort'], k['home']['name'], k['away']['name'], k['blv']['name'], k['status']) for v in kq for k in v['matchs'])
        for k in dq:
            tg = f"[COLOR red]{k[1]}[/COLOR]" if k[5]==1 else k[1]
            mau = f"[COLOR yellow]{k[2]} vs {k[3]}[/COLOR]"
            tenm = f'{tg} {mau} - {k[4]}' if k[4] else f'{tg} {k[2]} vs {k[3]}'
            addDir(tenm, 'list_caheo', idck=k[0], name=tenm, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_caheo':
        u = f"{homeweb}/v1/caheo/{params['idck']}.html"
        r = getlink(u, u, 1000)
        s = re.findall(r',name:"(.*?)",url:"(.*?)"', r.text)
        for v in s:
            if 'm3u8' in v[1] or 'flv' in v[1]:
                tenm = f'{v[0]} - {params["name"]}'
                addDir(tenm, 'play', id=v[1], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        if 'm3u8' in linkplay:
            hdr = f'Referer={homeweb}/&Origin={homeweb}&Keep-Alive=true&User-Agent={unquote(UA)}'
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
            play_item.setPath(linkplay)
        else:
            play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ!')

if __name__ == '__main__':
    try:
        router(sys.argv[2][1:])
    except:
        xbmcgui.Dialog().notification(addon_name, 'Không lấy được dữ liệu', ICON)