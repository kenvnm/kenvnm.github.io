from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from concurrent.futures import ThreadPoolExecutor
from html import unescape
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP1A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/605.1.15 EdgA/129.0.0.0'
uapi = 'https://apii.online/apii'
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def get_info_apiionline(x):
    r = getlink(f'{uapi}/phim/{x}',uapi,-1)
    try:
        kq = r.json()['movie']
        try:
            img = kq['thumb_url']
        except:
            img = ICON
        try:
            ten = unescape(kq['name'])
        except:
            pass
        try:
            mota = unescape(re.sub('<.*?>', '', kq['content']))
        except:
            mota = ten
        return (ten, img, mota)
    except:
        return None
def process_url(url):
    try:
        data = get_info_apiionline(url)
        return url, data
    except:
        return url, None
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('Tìm phim', searchimg, 'Tìm phim', 'search', is_folder=True)
        addDir('Phim mới', ICON, 'Phim mới', 'ds_apiionline', url = f'{uapi}/danh-sach/phim-moi-cap-nhat', p=1, is_folder=True)
        T = {'Thể loại': 'theloai',
        'Quốc gia': 'quocgia'}
        for b in T:
            addDir(b, ICON, b, T[b], is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'theloai':
        u = f'{uapi}/the-loai'
        resp = getlink(u, u, 1000)
        ri = resp.json()
        for k in ri:
            ten = unescape(k['name'])
            addDir(ten, ICON, ten, 'ds_apiionline', url = f"{uapi}/danh-sach?category={k['slug']}", p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'quocgia':
        u = f'{uapi}/quoc-gia'
        resp = getlink(u, u, 1000)
        ri = resp.json()
        for k in ri:
            ten = unescape(k['name'])
            addDir(ten, ICON, ten, 'ds_apiionline', url = f"{uapi}/danh-sach?country={k['slug']}", p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'ds_apiionline':
        next_page = params['p']
        match = params['url']
        n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
        resp = getlink(n, n, 1000)
        ri = resp.json()['items']
        urls = [k['slug'] for k in ri]
        length = len(urls)
        if length>0:
            with ThreadPoolExecutor(length) as ex:
                results = ex.map(process_url, urls)
            for (l, data) in results:
                if data is not None:
                    addDir(data[0], data[1], data[2], 'id_apiionline', id = l, is_folder=True)
            nextp = int(next_page) + 1
            addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', 'ds_apiionline', url = match, p=nextp, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            next_page = 1
            sr = quote_plus(query)
            match = f'{uapi}/danh-sach?search={sr}'
            n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
            resp = getlink(n, n, 1000)
            ri = resp.json()['items']
            urls = [k['slug'] for k in ri]
            length = len(urls)
            if length>0:
                with ThreadPoolExecutor(length) as ex:
                    results = ex.map(process_url, urls)
                for (l, data) in results:
                    if data is not None:
                        addDir(data[0], data[1], data[2], 'id_apiionline', id = l, is_folder=True)
                nextp = int(next_page) + 1
                addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', 'ds_apiionline', url = match, p=nextp, is_folder=True)
            endOfDirectory(HANDLE)
        else:
            quit()
    elif params['mode'] == 'id_apiionline':
        t = f'{uapi}/phim/{params["id"]}'
        resp = getlink(t, t, 1000)
        kq = resp.json()
        title = kq['movie']['name']
        mota = unescape(re.sub('<.*?>', '', kq['movie']['content']))
        anh = kq['movie']['thumb_url']
        b = ((k1['server_name'], k2['name'], k2['link_m3u8']) for k1 in kq['episodes'] for k2 in k1['server_data'] if 'link_m3u8' in k2)
        for k in b:
            tenm = f"[COLOR yellow]{k[0]}[/COLOR] Tập {k[1]} - {title}"
            if '[nc]' in k[0].lower():
                addDir(tenm, anh, mota, 'play_nc', url = k[2], is_folder=False)
            else:
                addDir(tenm, anh, mota, 'play_vn', url = k[2], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_nc':
        url = params['url']
        ref = domain(url)
        r = getlink(url, url, -1)
        file = re.search(r'"file".*?"(.*?)"', r.text)
        fileplay = f'{ref}{file[1]}' if file[1].startswith('/') else file[1]
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', fileplay.strip(), flags=re.UNICODE)
        hdr = f'Referer={ref}/&Origin={ref}&Keep-Alive=true&User-Agent={unquote(UA)}'
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'play_vn':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['url'].strip(), flags=re.UNICODE)
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ!')
if __name__ == '__main__':
    try:
        router(sys.argv[2][1:])
    except:
        xbmcgui.Dialog().notification(addon_name, 'Không lấy được dữ liệu', ICON)